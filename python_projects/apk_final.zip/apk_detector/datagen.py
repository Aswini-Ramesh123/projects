import pandas as pd
import random
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import CountVectorizer

# Expanded permission list with critical ones
permissions_list = [
    "INTERNET", "READ_CONTACTS", "ACCESS_FINE_LOCATION", "CAMERA", "WRITE_EXTERNAL_STORAGE",
    "SYSTEM_ALERT_WINDOW", "RECORD_AUDIO", "READ_SMS", "SEND_SMS", "ACCESS_NETWORK_STATE",
    "WRITE_SECURE_SETTINGS", "FOREGROUND_SERVICE", "QUERY_ALL_PACKAGES", "READ_PRIVILEGED_PHONE_STATE",
    "CAPTURE_SECURE_VIDEO_OUTPUT", "CAPTURE_VIDEO_OUTPUT", "BIND_ACCESSIBILITY_SERVICE", 
    "USE_FULL_SCREEN_INTENT", "READ_CLIPBOARD", "INSTALL_PACKAGES", "MODIFY_AUDIO_SETTINGS"
]

# Activities and Services lists
activities_list = ["MainActivity", "LoginActivity", "SettingsActivity", "CameraActivity", "MapsActivity"]
services_list = ["BackgroundService", "LocationService", "SyncService", "NotificationService"]

# APK Classification Labels
apk_classes = ["Malware", "Spyware", "Scam App", "Normal App"]

# Generate 1,000 synthetic APK records with class labels
data = []
for i in range(1000):
    apk_name = f"app_{i+1}.apk"
    permissions = random.sample(permissions_list, random.randint(3, len(permissions_list)))
    activities = random.sample(activities_list, random.randint(1, len(activities_list)))
    services = random.sample(services_list, random.randint(1, len(services_list)))
    apk_class = random.choice(apk_classes)  # Random class assignment
    
    data.append({
        "APK_Name": apk_name,
        "Permissions": ", ".join(permissions),
        "Activities": ", ".join(activities),
        "Services": ", ".join(services),
        "Class": apk_class
    })

# Convert to DataFrame and save as CSV
df = pd.DataFrame(data)
df.to_csv("classified_apk_dataset.csv", index=False)

print("Dataset with class labels saved as classified_apk_dataset.csv")

# ---- Correlation Analysis ----

# Convert categorical labels to numerical for correlation
df["Class"] = df["Class"].map({"Malware": 3, "Spyware": 2, "Scam App": 1, "Normal App": 0})

