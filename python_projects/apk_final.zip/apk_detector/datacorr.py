import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import CountVectorizer

# Load dataset
df = pd.read_csv("classified_apk_dataset.csv")

# Convert class labels to numeric values
df["Class"] = df["Class"].map({"Malware": 3, "Spyware": 2, "Scam App": 1, "Normal App": 0})

# Convert permissions to binary features (1 if present, 0 if not)
vectorizer = CountVectorizer(tokenizer=lambda x: x.split(", "), binary=True)
permissions_matrix = vectorizer.fit_transform(df["Permissions"])
permissions_df = pd.DataFrame(permissions_matrix.toarray(), columns=vectorizer.get_feature_names_out())

# Merge transformed permissions with dataset
df = pd.concat([df, permissions_df], axis=1)

# Drop non-numeric columns that don't affect correlation
df.drop(columns=["APK_Name", "Permissions", "Activities", "Services"], inplace=True)

# Compute correlation matrix
corr_matrix = df.corr()

# Save correlated dataset
df.to_csv("correlated_apk_dataset.csv", index=False)
print("Correlated dataset saved as correlated_apk_dataset.csv")

# Visualize the correlation using a heatmap
plt.figure(figsize=(12, 8))
sns.heatmap(corr_matrix, cmap="coolwarm", annot=False)
plt.title("Feature Correlation Heatmap")
plt.show()