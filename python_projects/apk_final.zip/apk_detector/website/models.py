from django.db import models




# Create your models here.
class Record(models.Model):
    object_name = models.CharField(max_length=255)  # Object name
    timestamp = models.DateTimeField(auto_now_add=True)  # Timestamp when the record is created

    def __str__(self):
        return self.object_name