from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
import pandas as pd
from bs4 import BeautifulSoup
from urllib import request
from . models import Record
from django.contrib.auth.decorators import login_required
import requests
import xml.etree.ElementTree as ET
from tensorflow.keras.models import load_model
import numpy as np
# Load trained model
pdf = pd.read_csv("preprocessed.csv")
cdf = pd.read_csv("classified_apk_dataset.csv")
idf = pd.read_csv("critical_apk_dataset.csv")

model = load_model("lcnn_apk_detection_model.h5")
# url2 = "https://matplotlib.org/tutorials/introductory/lifecycle.html#sphx-glr-tutorials-introductory-lifecycle-py"
# url = "https://www.crummy.com/software/BeautifulSoup/bs4/doc/"
# html = request.urlopen(url)

# doc =BeautifulSoup(html,"html.parser")
# print(doc.find_all('pre'))
# print("-------------")
# for k in doc.find_all('pre'):
#     print(str(k))
# print("-------------")   
# Create your views here.

def read_xml(file_path):
    tree = ET.parse(file_path)
    root = tree.getroot()

    app_info = {
        "Package Name": root.find("packageName").text,
        "App Name": root.find("appName").text,
        "Version Name": root.find("versionName").text,
        "Version Code": root.find("versionCode").text,
        "Is Verified": root.find("isVerified").text,
        "Network Required": root.find("networkRequired").text,
        "Min SDK Version": root.find("minSdkVersion").text,
        "Target SDK Version": root.find("targetSdkVersion").text,
        "Permissions": [perm.text for perm in root.find("permissions")],
        "Features": [feature.text for feature in root.find("features")],
        "Developer": {
            "Name": root.find("developer/name").text,
            "Email": root.find("developer/email").text,
            "Website": root.find("developer/website").text
        },
        "Size": root.find("size").text,
        "Last Updated": root.find("lastUpdated").text
    }

    return app_info

def home(request):

    return render(request,"home.html",{})

def scams(request):

    return render(request,"scams.html",{})

def lstm(request):

    return render(request,"lstm.html",{})

def preprocessing(request):

    return render(request,"preprocessing.html",{})

def algorithm(request):

    return render(request,"algorithm.html",{})


def choice(request):

    return render(request,"choice.html",{})

def app_login(request):
    error = ""
    if request.method=="POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username,password=password)
        if user is not None:
            login(request,user)
            return redirect('home')
        else:
            error = "Username or Password Error"
            return render(request,"login.html",{"error":error})

    return render(request,"login.html",{})

def app_signup(request):
    if request.method=="POST":
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        try:
            user = User.objects.create_user(username=username,password=password,email=email)
            user.save()
        except:
             return render(request,"signup.html",{"error":"UserName Already Taken"})
        return redirect('login')

    return render(request,"signup.html",{})

def data_form(request):
    all_permissions = ""
    predicted_label = "App not Supported"
    res = "Good APP"
    if request.method == "POST" and request.FILES.get("file"):
        xml_file = request.FILES["file"]
        file_path = f"media/{xml_file.name}"  # Save to media folder
        ex_file_path = f"media/{xml_file.name[:-4]}.xml"
        print(list(idf))
        selected_row = idf.query(f"APK_Name == '{xml_file.name}'")
        selected_row_index = selected_row.index
        print(selected_row_index[0])
        print(cdf["Permissions"],"99999")
        try:
            cdf["Permissions"] = cdf["Permissions"].apply(lambda x: x.split(","))
        except:
            cdf["Permissions"] = cdf["Permissions"].apply(lambda x: x[0].split(","))
        all_permissions = list(set((p for sublist in cdf["Permissions"] for p in sublist)))  
        print(all_permissions,"9999")
        with open(file_path, "wb+") as destination:
            for chunk in xml_file.chunks():
                destination.write(chunk)

        with open(ex_file_path, "wb+") as destination:
            for chunk in xml_file.chunks():
                destination.write(chunk)
        data = read_xml(ex_file_path)
        print(data)
        # is_v = 1 if data['Is Verified']=="true" else 0
        # is_n = 1 if data['Network Required']=="true" else 0
        #print(is_v,is_n)
        print(pdf.loc[selected_row_index[0]].values)
        data = np.array([pdf.loc[selected_row_index[0]].values[2:]])
        y_pred = (model.predict(data))
        predicted_class = np.argmax(y_pred, axis=1)

        # Convert predicted class to label
        class_mapping = {0: "Normal App", 1: "Scam App", 2: "Spyware", 3: "Malware"}
        predicted_label = class_mapping[predicted_class[0]]
        if predicted_label:
            return render(request,"result.html",{"res":predicted_label})
        # if is_v and is_n:
        #     res = "Good APP"
        # else:
        #     res = "Scam APP"
        print(res)

    return render(request,"data_form.html",{"res":predicted_label,"permissions":all_permissions})

def create_view(request):
    
    object = request.GET.get('name')
    

    # Create a new Contact object and save it to the database
    contact = Record(object_name=object)
    contact.save()

    # Redirect to a success page or display a success message
    # return HttpResponse('Thank you for your message!')
    return HttpResponse("Done")

@login_required(login_url="/login")
def items_list_view(request):
    contacts = Record.objects.all()
    return render(request, 'items_list.html', {'contacts': contacts})

from django.shortcuts import render, redirect, get_object_or_404

@login_required(login_url="/login")
def item_edit_view(request, id):
    contact = get_object_or_404(Contact, id=id)
    if request.method == 'POST':
        contact.name = request.POST.get('name')
        contact.email = request.POST.get('email')
        contact.phone = request.POST.get('phone')
        contact.message = request.POST.get('message')
        contact.save()
        return redirect('items')
    return render(request, 'edit_item.html', {'contact': contact})

@login_required(login_url="/login")
def item_delete_view(request, id):
    contact = get_object_or_404(Contact, id=id)
    if request.method == 'POST':
        contact.delete()
        return redirect('items')
    return render(request, 'delete_item.html', {'contact': contact})
def signout(request):
    logout(request)
    return redirect("home")